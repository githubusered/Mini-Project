// ********************Login Page****************************
let login = document.getElementById('login');
let password = document.getElementById('password');

function toJoin(){
    if(login.value === 'Admin' && password.value === '123456'){
        window.location.href = 'homePage.html'
    }else if(login.value !== 'Admin' && password.value === '123456'){
        login.style.border = `red`
        password.style.border = `green`
        alert('write right login ')
    }else if(login.value === 'Admin' && password.value !== '123456'){
        login.style.border = `2px solid green`
        password.style.border = `2px solid red`
        alert('write right  password')
    }else{
        login.style.border = `2px solid red`
        password.style.border = `2px solid red`
    }
}


// **********************Home Page***********************************\
let main = document.querySelector('#mainPage');

let images = [
    "kendani1.jpg",
    "kendani2.jpg",
    "kendani3.jpg",
    "building1.jpg",
    "building2.jpg",
    "building3.jpg",
    'coffee1.jpg',
    'coffee2.jpg',
    'coffee3.jpg'
]
let data = images.sort( (a, b)=>  {  
  return 0.5 - Math.random();
} )

let html = ""
for (let i = 0; i < data.length; i++) {
    html+= `<img src="images/${data[i]}" class="img">`
}
main.innerHTML = html;


// let article = document.getElementById('profileArticle');
let addImageDisp = document.querySelector('#addImageBtn');
let searchBox = document.querySelector(".search")

let seeImgTF = true;
let addImgTF = true;
let seeSearchTF = true;

function seeBase(){
    if(seeImgTF === true){
        
        if(addImgTF === false){
            addImageDisp.style.display = "none";
            addImgTF = true;
        }
        if(seeSearchTF === false){
            searchBox.style.display = "none";
            seeSearchTF = true;
        }

        main.style.display = "flex"
        seeImgTF = false
    }else{
        main.style.display = "none"
        seeImgTF= true
    }
}


//   **********************************Profile  Page************************************

function addPhoto(){
    if(addImgTF === true){

        if(seeImgTF === false){
            main.style.display = "none"
            seeImgTF= true
        }
        if(seeSearchTF === false){
            searchBox.style.display = "none";
            seeSearchTF = true;
        }

        addImageDisp.style.display = "block";
        addImgTF = false;
    }else{
        addImageDisp.style.display = "none";
        addImgTF = true
    }
}

function previewFile() {
    const preview = document.getElementById('chooseImg');
    const file = document.querySelector('input[type=file]').files[0];
    const reader = new FileReader();
  
    reader.addEventListener("load", () => {
      preview.src = reader.result;
    }, false);
  
    if (file) {
      reader.readAsDataURL(file);
      console.log(reader.result)
    }
  }
  document.querySelector(".searchInput").placeholder = "E.g. kendani1.../coffee3...";
  function seeSearch(){
    if(seeSearchTF === true){

        if(seeImgTF === false){
            main.style.display = "none"
            seeImgTF= true
        }
        if(addImgTF === false){
            addImageDisp.style.display = "none";
            addImgTF = true;
        }

        searchBox.style.display = "block";
        seeSearchTF = false;
    }else{
        searchBox.style.display = "none";
        seeSearchTF = true
    }
  }

let searchInput = document.querySelector(".searchInput");
let searchImgDiv = document.querySelector(".searchImg");

  function Search(){
    let memory = [];
    for(let i = 0; i < images.length; i++){
        let split2 = images[i].split(".");
        memory[i] = split2[0]
    }
    
    memory.forEach(img =>{
        if(searchInput.value === img){
            searchImgDiv.innerHTML=`<img src="images/${img}.jpg">`
        }
        if(searchInput.value !== img){
            searchImgDiv.innerHTML=`<p>
                There is no picture with the given name, whose name is
                 <span>"${searchInput.value}"</span> : Try again...
            </p>`
        }
    })
  }